# Crypto Trading Bot

This project is a crypto trading bot that uses machine learning to generate trading signals and send them to Telegram. The bot is designed to work with the Binance exchange and uses the 15-minute time frame for analysis.

## Project Structure

